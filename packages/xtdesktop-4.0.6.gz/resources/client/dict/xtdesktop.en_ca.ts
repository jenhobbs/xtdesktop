<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>Workbench</source>
        <translation></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Budget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation></translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CRM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Currencies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Roles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assignments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Post Production</source>
        <translation></translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Costing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Return Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Issue Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Remind me about this again.</source>
        <translation></translation>
    </message>
    <message>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>Open Items</source>
        <translation></translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ViewAPOpenItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Cash Receipts</source>
        <translation></translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Balance</source>
        <translation></translation>
    </message>
    <message>
        <source>Reconcile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>Schema</source>
        <translation></translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Liability</source>
        <translation></translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>Released</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Qty.</source>
        <translation></translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>Posted Value</source>
        <translation></translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Released</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Contact</source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Postal Code</source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Description</source>
        <translation></translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incident</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To-do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>61-90 Days</source>
        <translation></translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>Planned</source>
        <translation></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Firmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Amount</source>
        <translation></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Non-Inventory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Order#</source>
        <translation></translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>0+ Days</source>
        <translation></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>Type</source>
        <translation></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Reload</source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Ship Phone</source>
        <translation></translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># External</source>
        <translation></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source># Internal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Bookings</source>
        <translation></translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Type</source>
        <translation></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual Refresh Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

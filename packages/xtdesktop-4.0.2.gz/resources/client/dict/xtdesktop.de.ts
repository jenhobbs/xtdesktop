<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished">Arbeitsoberfläche</translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>Reporting</source>
        <translation type="unfinished">Berichtswesen</translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation>Abgleichen</translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation>Journalserie</translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation>Jahresabschlüsse</translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation>Bankkonten</translation>
    </message>
    <message>
        <source>Budget</source>
        <translation>Budget</translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation>Standardjournal</translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation>Transaktionen</translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation>Rohbilanz</translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation>Kontenplan</translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation>Hauptbuch</translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation>Forderungen</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Kunde</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation>Überwachte Konten</translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation>Abrechnung</translation>
    </message>
    <message>
        <source>Payables</source>
        <translation>Verbindlichkeiten</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation>Bereinigung</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Anbieter</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Auslagerung</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation>Workbench</translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation></translation>
    </message>
    <message>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation>Projektaufträge</translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation>Zwischenfälle</translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation>Meine Kontakte</translation>
    </message>
    <message>
        <source>To Do</source>
        <translation>Zu erledigen</translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation>Zeit und Kosten</translation>
    </message>
    <message>
        <source>Projects</source>
        <translation>Projekte</translation>
    </message>
    <message>
        <source>CRM</source>
        <translation>CRM</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Persönlich</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation>Ereignisverwaltung</translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation>Aufgabenkalener</translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation>Aufgabenliste</translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation>Körperschaftlich</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>Konten</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Angebote</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Kontakte</translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation>Adreßbuch</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation>Vorverkauf</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>Interessenten</translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation>Angebote nach Artikel</translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation>Verkaufschancen</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation>Kunden Workbench</translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation>Kontoverwaltung</translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation>Meine Konten</translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Screens</source>
        <translation type="unfinished">Masken</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Sicherheit</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>Produkte</translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation>Terminierungen</translation>
    </message>
    <message>
        <source>Assignments</source>
        <translation>Zuweisungen</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation>Währung</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation>Währungen</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>Skripte</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Erweiterungen</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Funktionen</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Benutzer</translation>
    </message>
    <message>
        <source>Items</source>
        <translation>Artikel</translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation>Stückliste</translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation>Warenbestand</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>Standort</translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation>Preisbildung</translation>
    </message>
    <message>
        <source>Commands</source>
        <translation>Befehle</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>Berichte</translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation>Wechselkurse</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>Entwicklung</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>Pflege</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>Lagerorte</translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Issue Material</source>
        <translation type="unfinished">Material ausgeben</translation>
    </message>
    <message>
        <source>Process</source>
        <translation>Verarbeiten</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Warenbestandsverfügbarkeit</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Rückschau</translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation>Rückschau Anfertigung</translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation>Materialverfügbarkeit</translation>
    </message>
    <message>
        <source>Return Material</source>
        <translation>Material zurückgeben</translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation>Produktion korrigieren</translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation>Fertigungsauftrag schliessen</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Drucken</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation>Planen</translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation>Fertigungsauftrag erstellen</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>Freigeben</translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation>Materialbedarf</translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation>Fertigungsaufträge</translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation>Produktion verbuchen</translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation>Anfertigungsaktivitäten</translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation>Auftragsübersicht</translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation>Ausschuß verbuchen</translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation>Anfertigung</translation>
    </message>
    <message>
        <source>Costing</source>
        <translation>Kostenermittlung</translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation type="unfinished">Hinweis: Der xTupe Desktop ist nicht verfügbar, wenn die Benutzervoreinstellungen so gesetzt sind, daß die Fenster als &apos;frei-schwebend&apos; angezeigt werden sollen.</translation>
    </message>
    <message>
        <source>Notice</source>
        <translation>Mitteilung</translation>
    </message>
    <message>
        <source>Remind me about this again.</source>
        <translation>Erneut daran erinnern.</translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>Vouchers</source>
        <translation type="unfinished">Bezugsbelege</translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation>Einkaufsauftrag erstellen</translation>
    </message>
    <message>
        <source>Payment</source>
        <translation>Bezahlung</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Warenbestandsverfügbarkeit</translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation>Zur Bezahlung auswählen</translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation>Offene Posten</translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation>Schecklauf</translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation>Ausgewählte Zahlungen</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Bestellen</translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation>Einkauf</translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation>Einkaufsanfragen</translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation>Scheckregister</translation>
    </message>
    <message>
        <source>ViewAPOpenItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Auslagerung</translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation>Nicht in Rng gestellte Eingänge</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation>Rückschau Einkauf</translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation>Einkaufsaktivitäten</translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation>Unverbuchte Wareneingänge</translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation>Einkaufsaufträge</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Drucken</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>Freigeben</translation>
    </message>
    <message>
        <source>Receive</source>
        <translation>Empfangen</translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation>Eingänge eingeben</translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Sales Orders</source>
        <translation type="unfinished">Verkaufsaufträge</translation>
    </message>
    <message>
        <source>Cash Receipts</source>
        <translation>Bareinnahmen</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Warenbestandsverfügbarkeit</translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation>Zur Fakturierung auswählen</translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation>Umsatzverlauf</translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation>Versand pflegen</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Bestellen</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Angebote</translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation>Neuer Kunde</translation>
    </message>
    <message>
        <source>Bill</source>
        <translation>Berechnen</translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation>Auftragsrückstand</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation>Rechnungen erstellen</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Umsatz</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Auslagerung</translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation>Rechnungen verbuchen...</translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation>Umsatzaktivitäten</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>Interessenten</translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship</source>
        <translation>Ausliefern</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation>Neuer Verkaufsauftrag</translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation>Zum Versand ausgeben</translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation>Packlisten drucken</translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Balance</source>
        <translation type="unfinished">Saldo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Reconcile...</source>
        <translation>Abgleichen...</translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Art</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>Masken</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>Skripte</translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation>Benutzerbefehle</translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation>Gespeicherte Prozeduren</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tables</source>
        <translation>Tabellen</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Auslöser</translation>
    </message>
    <message>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>Berichte</translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation>Rechte</translation>
    </message>
    <message>
        <source>Views</source>
        <translation>Ansichten</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Datenbank</translation>
    </message>
    <message>
        <source>Client</source>
        <translation>Client</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>Ordner</translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Equity</source>
        <translation type="unfinished">Eigenkapital</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation>Aufwand</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation>Erlös</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Neu laden</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Voreinstellungen...</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation>Verbindlichkeit</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation>Vermögen</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Art</translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished">Neu laden</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">Voreinstellungen...</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">Öffnen...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>Qty</source>
        <translation type="unfinished">Anz</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>Ausgestoßen</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Art</translation>
    </message>
    <message>
        <source>#</source>
        <translation>Nr.</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Offen</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>Freigegeben</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation>Geplant</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>In-Arbeit</translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Description</source>
        <translation type="unfinished">Bezeichnung</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>dieses Jahr</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>dieser Monat</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>diese Woche</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Neu laden</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>Klassenschlüssel</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>Anz.</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation>Planungsschlüssel</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>Artikelnummer</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Voreinstellungen...</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Heute</translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>Ordered</source>
        <translation type="unfinished">Bestellt</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation>Wdp.</translation>
    </message>
    <message>
        <source>Item#</source>
        <translation>Artikel #</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>Auftrag Nr.</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>Starttermin</translation>
    </message>
    <message>
        <source>UOM</source>
        <translation>M-E</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Erhalten</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>Freigegeben</translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation>Verbuchter Wert</translation>
    </message>
    <message>
        <source>Condition</source>
        <translation>Bedingung</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>Ausgestoßen</translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation>&apos;Work in Progress&apos; Wert</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Offen</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>In-Arbeit</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Fälligkeitsdatum</translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished">PLZ</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Land</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Bundesland</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>Kontakt</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>eMail</translation>
    </message>
    <message>
        <source>City</source>
        <translation>Stadt</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Phone</source>
        <translation type="unfinished">Telefon</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>Kontoname</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>Land</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Kontonr.</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Bundesland</translation>
    </message>
    <message>
        <source>City</source>
        <translation>Stadt</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>eMail</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation>PLZ</translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Project</source>
        <translation type="unfinished">Projekt</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Art</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>Starttermin</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Kontonr.</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation>Aufgabe löschen?</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation>Zugewiesen an</translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation>Parent Nr.</translation>
    </message>
    <message>
        <source>Task</source>
        <translation>Aufgabe</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Fälligkeitsdatum</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Besitzer</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>Kontoname</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation>Kundennr.</translation>
    </message>
    <message>
        <source>To-do</source>
        <translation>Zu erledigen</translation>
    </message>
    <message>
        <source>Incident</source>
        <translation>Zwischenfall</translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation>Wollen Sie den Aufgabenposten wirklich dauerhaft löschen?</translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0+ Tage</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90 Tage</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30 Tage</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>Insgesamt offen</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60 Tage</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>90+ Tage</translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>Requests</source>
        <translation type="unfinished">Anforderungen</translation>
    </message>
    <message>
        <source>Firmed</source>
        <translation>Unveränderlich gemacht</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation>Geplant</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>Nicht freigegeben</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Offen</translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation>Bei Empfang</translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation>Bezugsbelegt</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Art</translation>
    </message>
    <message>
        <source>#</source>
        <translation>Nr.</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Erhalten</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Name</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>Anz.</translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation>Aktion wird nicht unterstützt</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>diese Woche</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>dieses Jahr</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Anbieter</translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation>Einkäufer/-in</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>Artikelnummer</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation>Abweichungen</translation>
    </message>
    <message>
        <source>Non-Inventory</source>
        <translation>Nicht zum Warenbestand gehörig</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>dieser Monat</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Neu laden</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Heute</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Voreinstellungen...</translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished">Versand Telefon</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>Liefern mit</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Fälligkeitsdatum</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>Nicht freigegeben</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Offen</translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation>Anbieternr.</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>Kontakt</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation>Versand Kontakt</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>Auftrag Nr.</translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>61-90 Days</source>
        <translation type="unfinished">61-90 Tage</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation>0+ Tage</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>Insgesamt offen</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>90+ Tage</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30 Tage</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60 Tage</translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>To Bill</source>
        <translation type="unfinished">In Rng. zu stellen</translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation>In Rechnung gestellt</translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation>Beim Versand</translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation>Ausgeliefert</translation>
    </message>
    <message>
        <source>Pick</source>
        <translation>Entnehmen</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Art</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation>Aufträge</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Angebote</translation>
    </message>
    <message>
        <source>#</source>
        <translation>Nr.</translation>
    </message>
    <message>
        <source>To Print</source>
        <translation>Zu drucken</translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Kunde</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>Anz.</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>diese Woche</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Umsatz</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>dieses Jahr</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>dieser Monat</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Heute</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation>Vorbestellungen</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Neu laden</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Voreinstellungen...</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation>Verkäufer/-in</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation>Produktkategorie</translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Bill Contact</source>
        <translation type="unfinished">Fakturierung: Kontakt</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>Auftrag Nr.</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation>Kundennr.</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation>Versand Kontakt</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation>Versand Telefon</translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation>Liefern an</translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation>Fakturierung: Telefon</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>Liefern mit</translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation>Termin</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation>Rng. an</translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished">Neu laden</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">Voreinstellungen...</translation>
    </message>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># Internal</source>
        <translation type="unfinished">Anz. Interne</translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation>Client Adresse</translation>
    </message>
    <message>
        <source># External</source>
        <translation>Anz. Externe</translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation>Abfrage starten</translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Benutzername</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>eMail</translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation>Eigenname</translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Setup</source>
        <translation type="unfinished">Einrichtung</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Arbeitsoberfläche</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Willkommen</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation>Öffnen...</translation>
    </message>
    <message>
        <source>Sites</source>
        <translation>Standorte</translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Variances</source>
        <translation type="unfinished">Abweichungen</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Kunde</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation>Vorbestellungen</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Umsatz</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>Eingänge</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Artikel</translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation>Einkäufer/-in</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Art:</translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation>Rückschau Einkauf Voreinstellungen</translation>
    </message>
    <message>
        <source>This Week</source>
        <translation>Diese Woche</translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation>Umsatzverlauf Voreinstellungen</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>Klassenschlüssel</translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation>Anfertigungsrückschau Voreinstellungen</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation>Planungsschlüssel</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>Rückschau Einstellungen</translation>
    </message>
    <message>
        <source>This Month</source>
        <translation>Dieser Monat</translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation>Zeitrahmen:</translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation>Gruppe nach:</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Anbieter</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Heute</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation>Produktkategorie</translation>
    </message>
    <message>
        <source>This Year</source>
        <translation>Dieses Jahr</translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation>Verkäufer/-in</translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Liability</source>
        <translation type="unfinished">Verbindlichkeit</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Kontonr.</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation>Vermögen</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Art</translation>
    </message>
    <message>
        <source>Selection Preferences</source>
        <translation>Auswahl Voreinstellungen</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation>Eigenkapital</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation>Erlös</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation>Aufwand</translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation>Konten auswählen, um zu überwachen:</translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

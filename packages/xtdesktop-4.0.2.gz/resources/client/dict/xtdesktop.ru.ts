<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>b</source>
        <translation></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Клиент</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">Поставщик</translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation type="unfinished">План Счетов</translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation type="unfinished">Бухгалтерия</translation>
    </message>
    <message>
        <source>Budget</source>
        <translation type="unfinished">Бюджет</translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished">Резервы</translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation type="unfinished">Сделки</translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CRM</source>
        <translation type="unfinished">Маркетинг</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished">Проект</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation type="unfinished">Контакты</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation type="unfinished">Работа с заказчиками</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Do</source>
        <translation type="unfinished">Задача</translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation type="unfinished">События</translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Commands</source>
        <translation type="unfinished">Команды</translation>
    </message>
    <message>
        <source>Assignments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="unfinished">Позиции</translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Roles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site</source>
        <translation type="unfinished">Место</translation>
    </message>
    <message>
        <source>Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currency</source>
        <translation type="unfinished">Валюта</translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Return Material</source>
        <translation></translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation type="unfinished">Закрыть Заказ-Наряд</translation>
    </message>
    <message>
        <source>Issue Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Печать</translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation type="unfinished">Создать Наряд-заказ</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History</source>
        <translation type="unfinished">История</translation>
    </message>
    <message>
        <source>Costing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Notice</source>
        <translation></translation>
    </message>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remind me about this again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>Order</source>
        <translation></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ViewAPOpenItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation type="unfinished">Платёж</translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Печать</translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Post Invoices</source>
        <translation></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cash Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship</source>
        <translation type="unfinished">Отгрузка</translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation type="unfinished">Оплачиваемый Заказ</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation type="unfinished">Задать Отгрузку</translation>
    </message>
    <message>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished">Продажа</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished">Резервы</translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Name</source>
        <translation></translation>
    </message>
    <message>
        <source>Reconcile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished">Баланс</translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>Privileges</source>
        <translation></translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="unfinished">Картинки</translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Описание</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Liability</source>
        <translation></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">Активы</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished">Баланс</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Описание</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished">Номер</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished">Доход</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Расход</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished">Объективность</translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">Открыть...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>Exploded</source>
        <translation></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished">№</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished">Кол</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Released</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Description</source>
        <translation></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Код Класса</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">Кол.</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished">Артикул</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Выручка</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>UOM</source>
        <translation></translation>
    </message>
    <message>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Дата начала</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Получено</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Описание</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Статус</translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation type="unfinished">Склд.</translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation type="unfinished">Заказано</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Released</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Address</source>
        <translation></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished">Номер</translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished">Город</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished">Контакт</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">Телефон</translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished">Область</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished">Индекс</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Address</source>
        <translation></translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation type="unfinished">Клиент</translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished">Город</translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished">Область</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished">Индекс</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">Телефон</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Delete</source>
        <translation></translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To-do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Описание</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation type="unfinished">Клиент</translation>
    </message>
    <message>
        <source>Incident</source>
        <translation type="unfinished">Событие</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Статус</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="unfinished">Задача</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Дата начала</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation type="unfinished">Закреплен за</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="unfinished">Приоритет</translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished">Проект</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>61-90 Days</source>
        <translation></translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0+ Дней</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished">31-60 Дней</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">0-30 Дней</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished">Всего Открыто</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation type="unfinished">Баланс</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Статус</translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>Vouchered</source>
        <translation></translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished">№</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Firmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Получено</translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Amount</source>
        <translation></translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Выручка</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Non-Inventory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">Кол.</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Описание</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished">Артикул</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">Поставщик</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Amount</source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished">Контакт</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Статус</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished">Телефон</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>Balance</source>
        <translation></translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0+ Дней</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">0-30 Дней</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished">Всего Открыто</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Статус</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation type="unfinished">61-90 Дней</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished">31-60 Дней</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>To Bill</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation type="unfinished">В доставке</translation>
    </message>
    <message>
        <source>#</source>
        <translation type="unfinished">№</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation type="unfinished">Заказы</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation type="unfinished">Резервы</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation type="unfinished">Отгружено</translation>
    </message>
    <message>
        <source>Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation type="unfinished">Счёт</translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>this Month</source>
        <translation></translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation type="unfinished">Менеджер.</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">Кол.</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Клиент</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Описание</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished">Продажа</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Amount</source>
        <translation></translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation type="unfinished">Дата Опл</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># External</source>
        <translation></translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source># Internal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished">Имя пользователя</translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation type="unfinished">Полное Имя</translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">Открыть...</translation>
    </message>
    <message>
        <source>Sites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Customer</source>
        <translation></translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Код Класса</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Позиция</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Выручка</translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">Поставщик</translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished">Тип:</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation type="unfinished">Продажа</translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Selection Preferences</source>
        <translation></translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished">Объективность</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Расход</translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished">Доход</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Описание</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished">Обязательства</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">Активы</translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

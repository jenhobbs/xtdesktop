<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>Payables</source>
        <translation type="unfinished">Dettes</translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation>Plan de comptes</translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation>Rapport</translation>
    </message>
    <message>
        <source>Budget</source>
        <translation>Budget</translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation>Journal standard</translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation>Rapprocher</translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation>Entrées du journal</translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation>Comptes bancaires</translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation>Redressement</translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation>Etats financiers</translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation>Assistant</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation>Comptes suivis</translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation>Balance</translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation>Mouvements</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>En attente</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Fournisseur</translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation>Comptabilité</translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation>Grand Livre</translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation>Créances</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Client</translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation></translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation>Assistant client</translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation>Entreprise</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Personnel</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Contacts</translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation>Carnet d&apos;&apos;adresses</translation>
    </message>
    <message>
        <source>CRM</source>
        <translation>GRC</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation>Gestionnaire d&apos;&apos;évèn.</translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation>Liste de Tâches</translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation>Agenda des tâches</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>Clients</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>Prospects</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>Projet</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation>Avant-ventes</translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation>Opportunités</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Devis</translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation>Devis par Article</translation>
    </message>
    <message>
        <source>Projects</source>
        <translation>Projets</translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation>Charges &amp; Budgets</translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation>Gestion de comptes</translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation>Commandes projet</translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation>Incidents</translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation>Mes clients</translation>
    </message>
    <message>
        <source>To Do</source>
        <translation>Tâche</translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation>Mes contacts</translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Reports</source>
        <translation>Etats</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation>MetaSQL</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Extensions</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>Scripts</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>Ecrans</translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation>Taux de change</translation>
    </message>
    <message>
        <source>Commands</source>
        <translation>Commandes</translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation>Devises</translation>
    </message>
    <message>
        <source>Currency</source>
        <translation>Devise</translation>
    </message>
    <message>
        <source>Assignments</source>
        <translation>Affectations</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Utilisateurs</translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation>Plannifications</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>Emplacements</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation>Articles</translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation>Stock</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>Site</translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation>Liste d&apos;&apos;articles</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>Produits</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>Maintenance</translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation>Chiffrage</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Sécurité</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Profils</translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Design</source>
        <translation>Conception</translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Material Availability</source>
        <translation type="unfinished">Disponibilité des composants</translation>
    </message>
    <message>
        <source>Return Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="unfinished">Traiter</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation>Fabrication</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Disponibilité en stock</translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished">Archivage</translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation>Créer ordre de travail</translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimer</translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation>Fermer l&apos;&apos;ordre de travail</translation>
    </message>
    <message>
        <source>Issue Material</source>
        <translation>Elèments à émettre</translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation>Production corrigée</translation>
    </message>
    <message>
        <source>Costing</source>
        <translation>Prix de revient</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historique</translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation type="unfinished">Reporter Production</translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation>Activités de fabrication</translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation>Historique de fabrication</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation>étiquette</translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation type="unfinished">Bons de Travail</translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation type="unfinished">Remarque : Le bureau xTuple n&apos;&apos;est disponible que quand les préférences utilisateur intègrent les fenêtres flottantes.</translation>
    </message>
    <message>
        <source>Remind me about this again.</source>
        <translation>Me le rappeler ultérieurement.</translation>
    </message>
    <message>
        <source>Notice</source>
        <translation>Remarque</translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>ViewAPOpenItems</source>
        <translation></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation>Créer une commande</translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation>Bon de commande</translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation>Demandes d&apos;&apos;achat</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Commandes</translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation>Achat</translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation>Créances fournisseur</translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation>Livraisons non facturées</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimer</translation>
    </message>
    <message>
        <source>label</source>
        <translation>Etiquette</translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation>Livre des chèques</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Disponibilité en stock</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>En attente</translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation>Chèques à émettre</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>Archivage</translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation>Réceptions non enregistrées</translation>
    </message>
    <message>
        <source>Payment</source>
        <translation>Règlements</translation>
    </message>
    <message>
        <source>Receive</source>
        <translation>Réception</translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation>Sélection pour règlement</translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation>Reçus</translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation>Pièce Justificative</translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation>Historique par fournisseur</translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation>Règlements sélectionnés</translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation>Historique achat</translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Order</source>
        <translation></translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation type="unfinished">Reporter Factures</translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Ventes</translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation type="unfinished">Créer les Factures</translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cash Receipts</source>
        <translation type="unfinished">Encaissements</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation type="unfinished">En attente</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Devis</translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation type="unfinished">Commandes Client</translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation type="unfinished">Prospects</translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation type="unfinished">Mettre à Jour Expédition</translation>
    </message>
    <message>
        <source>Ship</source>
        <translation>Expédier</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation type="unfinished">Disponibilité en stock</translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation type="unfinished">Sélectionner pour Facturation</translation>
    </message>
    <message>
        <source>Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Balance</source>
        <translation type="unfinished">Solde</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Reconcile...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>MetaSQL</source>
        <translation></translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screens</source>
        <translation type="unfinished">Ecrans</translation>
    </message>
    <message>
        <source>Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="unfinished">Images</translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation type="unfinished">Etats</translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation type="unfinished">Scripts</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Liability</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Numéro</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">Compte dActif</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Solde</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Charges</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">Ouvrir...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>#</source>
        <translation type="unfinished">n°</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished">Qté</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Released</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Item Number</source>
        <translation></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Réceptions</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Code de Classe</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished">Code de Planificateur</translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>Condition</source>
        <translation></translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation type="unfinished">Entr.</translation>
    </message>
    <message>
        <source>UOM</source>
        <translation>Unit.</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>Cde n°</translation>
    </message>
    <message>
        <source>Item#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Etat</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Reçu</translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation type="unfinished">Commandé</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Avant le</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>Début le</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Released</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Country</source>
        <translation></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished">Province</translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished">Ville</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adresse</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Numéro</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished">Personne-ressource</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished">Code Postal</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Postal Code</source>
        <translation></translation>
    </message>
    <message>
        <source>Country</source>
        <translation type="unfinished">Pays</translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished">Province</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>Nom Client</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Client n°</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Adresse</translation>
    </message>
    <message>
        <source>City</source>
        <translation type="unfinished">Ville</translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Task</source>
        <translation></translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished">Projet</translation>
    </message>
    <message>
        <source>Incident</source>
        <translation type="unfinished">Incident</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Propriétaire</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Avant le</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorité</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Client n°</translation>
    </message>
    <message>
        <source>To-do</source>
        <translation>Tâche</translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>Nom Client</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Supprimer</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Etat</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation>Affecté à</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>Début le</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation>N°parent</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>61-90 Days</source>
        <translation></translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished">31-60 Jours</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">0-30 Jours</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0+ Jours</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Solde</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished">Total Ouvert</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Etat</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>Unreleased</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>#</source>
        <translation>n°</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Reçu</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Firmed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>this Month</source>
        <translation></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation type="unfinished">Numéro Article</translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Non-Inventory</source>
        <translation type="unfinished">Non Stocké</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Fournisseur</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Réceptions</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Ship Phone</source>
        <translation></translation>
    </message>
    <message>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished">Expédié Par</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation type="unfinished">Personne-ressource</translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation>Fournisseur n°</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Etat</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>Cde n°</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Avant le</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>Status</source>
        <translation type="unfinished">Etat</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Solde</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation type="unfinished">Total Ouvert</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation type="unfinished">31-60 Jours</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">0-30 Jours</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation type="unfinished">61-90 Jours</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0+ Jours</translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>Invoiced</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation type="unfinished">A Expédition</translation>
    </message>
    <message>
        <source>Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>#</source>
        <translation>n°</translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation type="unfinished">Expédié</translation>
    </message>
    <message>
        <source>To Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orders</source>
        <translation type="unfinished">Commandes</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Devis</translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Bookings</source>
        <translation></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Client</translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished">Catégorie de Produits</translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation type="unfinished">Représentant</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Ventes</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Order#</source>
        <translation type="unfinished">Cde n°</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation type="unfinished">Expédié Par</translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation>Date prévue</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># External</source>
        <translation></translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source># Internal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Email</translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation type="unfinished">Nom Propre</translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished">Nom Utilisateur</translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Sites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">Ouvrir...</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation type="unfinished">Installation</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Accueil</translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Group By:</source>
        <translation></translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished">Catégorie de Produits</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Réceptions</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Code de Classe</translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished">Code de Planificateur</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Fournisseur</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Article</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Client</translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Ventes</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Type</source>
        <translation></translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Client n°</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Description</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation type="unfinished">Compte dActif</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished">Compte de Passif</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Charges</translation>
    </message>
    <message>
        <source>Selection Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

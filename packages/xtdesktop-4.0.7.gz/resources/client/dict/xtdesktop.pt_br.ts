<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>General Ledger</source>
        <translation type="unfinished">Razão</translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation>Contabilidade</translation>
    </message>
    <message>
        <source>Payables</source>
        <translation>A Pagar</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation>Resenha</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Vencimento</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Fornecedor</translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation>A Receber</translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation>Plano de Contas</translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation>Diário Padrão</translation>
    </message>
    <message>
        <source>Budget</source>
        <translation>Orçamento</translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation>Conciliação</translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation>Ajuste</translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation>Balanço</translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation>Transações</translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation>Balancete</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation>Contas Bancárias</translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation></translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation>To Do Lista</translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation>To Do Calendário</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation>Administração de Eventos</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Pessoal</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation>Pré-Venda</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>Contas</translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation>Agenda</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Contatos</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>Interessados</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation>Cotações por Item</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Cotações</translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation>Oportunidades</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>Projeto</translation>
    </message>
    <message>
        <source>Projects</source>
        <translation>Projetos</translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation>Ocorrências</translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation>Carteira de Clientes</translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation>Administração de Conta</translation>
    </message>
    <message>
        <source>To Do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation>Minhas Contas</translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation>Meus Contatos</translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation>Corporativo</translation>
    </message>
    <message>
        <source>CRM</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Assignments</source>
        <translation>Assinaturas</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>Manutenção</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>Produtos</translation>
    </message>
    <message>
        <source>Items</source>
        <translation>Itens</translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation>Lista de Materiais</translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation>Agendamentos</translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation>Estoque</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site</source>
        <translation>Local</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Segurança</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Usuários</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Papéis</translation>
    </message>
    <message>
        <source>Currency</source>
        <translation>Moeda</translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation>Moedas</translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation>Taxas de Câmbio</translation>
    </message>
    <message>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>Telas</translation>
    </message>
    <message>
        <source>Commands</source>
        <translation>Comandos</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>Scripts</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>Relatórios</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Process</source>
        <translation>Processo</translation>
    </message>
    <message>
        <source>Issue Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation>Fechar Ordem de Trabalho</translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation>Criar Ordem de Trabalho</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation>Manufatura</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Estoque Disponível</translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation>Liberar</translation>
    </message>
    <message>
        <source>Return Material</source>
        <translation>Retorno de Material</translation>
    </message>
    <message>
        <source>Costing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>History</source>
        <translation>Histórico</translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation>Agendamento de Ordem</translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Orders</source>
        <translation type="unfinished">Ordens de Trabalho</translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Remind me about this again.</source>
        <translation></translation>
    </message>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>Select for Payment</source>
        <translation type="unfinished">Selecionar para Pagamento</translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation>Entrada de Receitas</translation>
    </message>
    <message>
        <source>ViewAPOpenItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation>Comprovantes</translation>
    </message>
    <message>
        <source>Receive</source>
        <translation>Receber</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>Liberar</translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation>Compras</translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation>Requisições de Compra</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Pedido</translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation>Criar Pedido de Compra</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Estoque Disponível</translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation>Receitas não Lançadas</translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Payment</source>
        <translation>Pagamento</translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation type="unfinished">Registro de Cheque</translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation>Pagamentos Selecionados</translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Vencimento</translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation type="unfinished">Itens Abertos</translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation>Pedidos de Compra</translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Order</source>
        <translation type="unfinished">Pedido</translation>
    </message>
    <message>
        <source>Bill</source>
        <translation>Cobrança</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Vendas</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>Interessados</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation>Novo Pedido de Venda</translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation>Novo Cliente</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Cotações</translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation type="unfinished">Pedidos em Carteira</translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship</source>
        <translation>Envio</translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation>Manutenção do Envio</translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Estoque Disponível</translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation>Selecionar para Cobrança</translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation>Pedidos de Venda</translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation>Criar Faturas</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation>Lançar Faturas</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Vencimento</translation>
    </message>
    <message>
        <source>Cash Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Reconcile...</source>
        <translation type="unfinished">Reconciliar...</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>Screens</source>
        <translation type="unfinished">Telas</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>Relatórios</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>Scripts</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Imagens</translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Liability</source>
        <translation></translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Despesa</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation>Ativo</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Número</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">Abrir...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>Planned</source>
        <translation></translation>
    </message>
    <message>
        <source>Qty</source>
        <translation>Qt</translation>
    </message>
    <message>
        <source>#</source>
        <translation>nº</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Aberto</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>Liberado</translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descrição</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>Número do item</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>Qt.</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>Código de classe</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Recibos</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>este Mês</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoje</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished">Código de Planeamento</translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>Released</source>
        <translation type="unfinished">Liberado</translation>
    </message>
    <message>
        <source>Item#</source>
        <translation>nº do item</translation>
    </message>
    <message>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Aberto</translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Data Limite</translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation type="unfinished">Armzs.</translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Recebido</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UOM</source>
        <translation>UDM</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>Data de Início</translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Phone</source>
        <translation type="unfinished">Telefone</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Número</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>Contato</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Endereço</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <source>City</source>
        <translation>Cidade</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>Account Name</source>
        <translation type="unfinished">Nome da Conta</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Conta#</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Telefone</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>City</source>
        <translation>Cidade</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Endereço</translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Customer#</source>
        <translation></translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>Data de Início</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation>Atribuído a</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>Nome da Conta</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Data Limite</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Conta#</translation>
    </message>
    <message>
        <source>Parent#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To-do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Proprietário</translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task</source>
        <translation>Tarefa</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>Projeto</translation>
    </message>
    <message>
        <source>Incident</source>
        <translation>Ocorrência</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0+ Dias</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60 Dias</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30 Dias</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90 Dias</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>Total em aberto</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>90+ Dias</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Firmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>#</source>
        <translation>nº</translation>
    </message>
    <message>
        <source>Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Aberto</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished">Recebido</translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Qty.</source>
        <translation type="unfinished">Qt.</translation>
    </message>
    <message>
        <source>Non-Inventory</source>
        <translation>Não Estocado</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Recibos</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>este Mês</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoje</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Fornecedor</translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>Número do item</translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Valor</translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Order#</source>
        <translation></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Aberto</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Telefone</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Data Limite</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>Enviar Por</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>Contato</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>0-30 Days</source>
        <translation type="unfinished">0-30 Dias</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90 Dias</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation>0+ Dias</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>Total em aberto</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60 Dias</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>90+ Dias</translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>At Shipping</source>
        <translation></translation>
    </message>
    <message>
        <source>To Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation>Faturado</translation>
    </message>
    <message>
        <source>To Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Orders</source>
        <translation type="unfinished">Pedidos</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Cotações</translation>
    </message>
    <message>
        <source>#</source>
        <translation>nº</translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>este Mês</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished">Pedidos</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Vendas</translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation type="unfinished">Rel. de Vendas:</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>Qt.</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoje</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Ship Contact</source>
        <translation></translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>Enviar Por</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation>Cobrar a</translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation type="unfinished">Data de Agendamento</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># External</source>
        <translation></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished">Nome de Utilizador</translation>
    </message>
    <message>
        <source># Internal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Bem-Vindo</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation>Abrir...</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Manufacture History Preferences</source>
        <translation></translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished">Tipo:</translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation type="unfinished">Recibos</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Item</translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation type="unfinished">Pedidos</translation>
    </message>
    <message>
        <source>This Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This Month</source>
        <translation>Este Mês</translation>
    </message>
    <message>
        <source>This Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoje</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Vendas</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>Código de classe</translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Fornecedor</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation type="unfinished">Código de Planeamento</translation>
    </message>
    <message>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Conta#</translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Despesa</translation>
    </message>
    <message>
        <source>Liability</source>
        <translation type="unfinished">Responsabilidade</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asset</source>
        <translation>Ativo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual Refresh Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

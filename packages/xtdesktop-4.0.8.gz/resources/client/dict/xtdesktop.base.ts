<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>desktop</name>
    <message>
        <location filename="../uiforms/desktop.ui" line="21"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="21"/>
        <location filename="../uiforms/desktopAccounting.ui" line="41"/>
        <source>Accounting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="48"/>
        <location filename="../uiforms/desktopAccounting.ui" line="455"/>
        <source>Payables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="63"/>
        <location filename="../uiforms/desktopAccounting.ui" line="141"/>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="85"/>
        <location filename="../uiforms/desktopAccounting.ui" line="163"/>
        <source>Workbench</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="91"/>
        <location filename="../uiforms/desktopAccounting.ui" line="169"/>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="104"/>
        <source>Vendor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="126"/>
        <location filename="../uiforms/desktopAccounting.ui" line="477"/>
        <source>Receivables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="182"/>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="204"/>
        <source>General Ledger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="219"/>
        <source>Chart of Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="241"/>
        <source>Budget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="257"/>
        <source>Standard Journal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="279"/>
        <source>Journal Series</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="298"/>
        <location filename="../uiforms/desktopAccounting.ui" line="433"/>
        <source>Bank Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="313"/>
        <source>Adjustment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="335"/>
        <source>Reconcile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="354"/>
        <source>Reporting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="369"/>
        <source>Financial Statements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="388"/>
        <source>Trial Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="410"/>
        <source>Transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="499"/>
        <source>Monitored Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopAccounting.ui" line="537"/>
        <location filename="../uiforms/desktopAccounting.ui" line="553"/>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="21"/>
        <source>CRM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="41"/>
        <source>Corporate Relationship Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="48"/>
        <source>Personal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="63"/>
        <source>Event Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="85"/>
        <source>To Do Calendar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="104"/>
        <source>To Do List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="126"/>
        <source>Corporate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="141"/>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="163"/>
        <source>Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="182"/>
        <source>Address Book</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="204"/>
        <source>Pre-Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="219"/>
        <source>Prospects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="238"/>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="254"/>
        <source>Quotes by Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="276"/>
        <source>Opportunities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="282"/>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="295"/>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="310"/>
        <source>Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="332"/>
        <source>Time &amp; Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="351"/>
        <source>Project Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="373"/>
        <source>Account Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="388"/>
        <source>Customer Workbench</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="410"/>
        <source>Incidents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="433"/>
        <source>To Do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="455"/>
        <source>My Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopCRM.ui" line="477"/>
        <source>My Accounts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="21"/>
        <location filename="../uiforms/desktopMaintenance.ui" line="42"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="49"/>
        <source>Products</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="64"/>
        <source>Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="86"/>
        <source>Bill of Materials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="142"/>
        <source>Inventory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="157"/>
        <source>Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="179"/>
        <source>Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="185"/>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="235"/>
        <source>Pricing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="250"/>
        <source>Schedules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="272"/>
        <source>Assignments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="328"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="343"/>
        <source>Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="365"/>
        <source>Roles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="421"/>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="436"/>
        <source>Currencies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="455"/>
        <source>coin_clock_48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="458"/>
        <source>Exchange Rates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="514"/>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="529"/>
        <source>Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="548"/>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="570"/>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="592"/>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="614"/>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMaintenance.ui" line="637"/>
        <source>Extensions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="21"/>
        <location filename="../uiforms/desktopManufacture.ui" line="41"/>
        <source>Manufacture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="48"/>
        <source>Plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="63"/>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="95"/>
        <source>Create Work Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="127"/>
        <source>Material Requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="159"/>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="178"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="210"/>
        <source>Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="251"/>
        <source>Issue Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="267"/>
        <source>Close Work Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="286"/>
        <source>Return Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="331"/>
        <source>Costing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="350"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="369"/>
        <source>Post Production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="388"/>
        <source>Post Scrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="407"/>
        <source>Order Schedule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="429"/>
        <source>Material Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="448"/>
        <source>Correct Production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="471"/>
        <source>Manufacture Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="493"/>
        <source>Manufacture History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="531"/>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="547"/>
        <location filename="../uiforms/desktopManufacture.ui" line="563"/>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopManufacture.ui" line="578"/>
        <source>Work Orders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <location filename="../scripts/desktopMenuBar.js" line="17"/>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/desktopMenuBar.js" line="24"/>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/desktopMenuBar.js" line="63"/>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/desktopMenuBar.js" line="127"/>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/desktopMenuBar.js" line="161"/>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/desktopMenuBar.js" line="161"/>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/desktopMenuBar.js" line="163"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/desktopMenuBar.js" line="163"/>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopMenuBar.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <location filename="../uiforms/desktopNotice.ui" line="21"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopNotice.ui" line="33"/>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopNotice.ui" line="43"/>
        <source>Remind me about this again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="21"/>
        <location filename="../uiforms/desktopPurchase.ui" line="41"/>
        <source>Purchase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="48"/>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="63"/>
        <source>Purchase Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="82"/>
        <source>Create Purchase Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="104"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="123"/>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="181"/>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="213"/>
        <source>Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="228"/>
        <source>Enter Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="247"/>
        <source>Unposted Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="266"/>
        <source>Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="281"/>
        <source>Vouchers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="303"/>
        <source>Select for Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="322"/>
        <source>Selected Payments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="341"/>
        <source>Check Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="360"/>
        <source>Check Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="379"/>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="385"/>
        <source>dspTimePhasedOpenAPItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="388"/>
        <source>ViewAPOpenItems</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="398"/>
        <source>Uninvoiced Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="420"/>
        <source>Open Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="482"/>
        <source>Purchase Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="504"/>
        <source>Purchase History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="542"/>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="558"/>
        <location filename="../uiforms/desktopPurchase.ui" line="574"/>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopPurchase.ui" line="589"/>
        <source>Purchase Orders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="21"/>
        <location filename="../uiforms/desktopSales.ui" line="41"/>
        <source>Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="48"/>
        <source>Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="63"/>
        <source>Prospects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="98"/>
        <source>New Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="120"/>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="155"/>
        <source>New Sales Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="177"/>
        <location filename="../uiforms/desktopSales.ui" line="256"/>
        <source>Ship</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="192"/>
        <source>Print Packing Lists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="227"/>
        <source>Issue To Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="275"/>
        <source>Maintain Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="297"/>
        <source>Inventory Availability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="316"/>
        <source>Backlog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="338"/>
        <source>Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="353"/>
        <source>Select for Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="372"/>
        <source>Create Invoices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="378"/>
        <source>dspBillingSelections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="391"/>
        <source>Post Invoices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="410"/>
        <source>Aging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="429"/>
        <source>Cash Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="504"/>
        <source>Sales Activities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="526"/>
        <source>Sales History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="564"/>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="580"/>
        <location filename="../uiforms/desktopSales.ui" line="596"/>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSales.ui" line="608"/>
        <source>Sales Orders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="14"/>
        <location filename="../uiforms/desktopSocial.ui" line="33"/>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="55"/>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="85"/>
        <location filename="../uiforms/desktopSocial.ui" line="101"/>
        <location filename="../uiforms/desktopSocial.ui" line="220"/>
        <location filename="../uiforms/desktopSocial.ui" line="236"/>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="122"/>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="142"/>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="135"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="169"/>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="188"/>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/desktopSocial.ui" line="251"/>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <location filename="../scripts/dockBankBal.js" line="24"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockBankBal.js" line="25"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockBankBal.js" line="99"/>
        <source>Reconcile...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <location filename="../scripts/dockExtensions.js" line="24"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="25"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="26"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="65"/>
        <source>Scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="66"/>
        <source>Custom Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="67"/>
        <source>Stored Procedures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="68"/>
        <source>Triggers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="69"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="70"/>
        <source>MetaSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="71"/>
        <source>Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="72"/>
        <source>Reports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="73"/>
        <source>Schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="74"/>
        <source>Tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="75"/>
        <source>Screens</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="76"/>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="77"/>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="78"/>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockExtensions.js" line="79"/>
        <source>Database</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="36"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="42"/>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="45"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="46"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="47"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="48"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="110"/>
        <source>Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="111"/>
        <source>Liability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="112"/>
        <source>Revenue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="113"/>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockGLAccounts.js" line="114"/>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <location filename="../scripts/dockMessageHistory.js" line="23"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMessageHistory.js" line="29"/>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMessageHistory.js" line="87"/>
        <source>Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMessageHistory.js" line="158"/>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="24"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="25"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="26"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="27"/>
        <source>Qty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="70"/>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="71"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="72"/>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="73"/>
        <source>Released</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgActive.js" line="74"/>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="39"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="45"/>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="123"/>
        <source>Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="126"/>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="128"/>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="130"/>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="132"/>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="258"/>
        <source>Class Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="259"/>
        <location filename="../scripts/dockMfgHist.js" line="264"/>
        <location filename="../scripts/dockMfgHist.js" line="269"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="263"/>
        <source>Item Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="268"/>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="272"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgHist.js" line="273"/>
        <source>Qty.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="24"/>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="25"/>
        <source>Item#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="26"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="28"/>
        <source>Whs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="29"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="30"/>
        <source>Ordered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="31"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="32"/>
        <source>UOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="33"/>
        <source>Start Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="34"/>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="35"/>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="38"/>
        <source>Posted Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="39"/>
        <source>WIP Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="83"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="84"/>
        <source>Exploded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="85"/>
        <source>Released</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMfgOpen.js" line="86"/>
        <source>In Process</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="23"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="24"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="25"/>
        <source>Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="26"/>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="27"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="28"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="29"/>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="30"/>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="31"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyAccounts.js" line="32"/>
        <source>Postal Code</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="23"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="24"/>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="25"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="26"/>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="27"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="28"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="29"/>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="30"/>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="31"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyContacts.js" line="32"/>
        <source>Postal Code</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="24"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="25"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="26"/>
        <source>Assigned To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="27"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="28"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="29"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="30"/>
        <source>Start Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="31"/>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="32"/>
        <source>Parent#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="33"/>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="34"/>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="35"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="36"/>
        <source>Owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="66"/>
        <source>Delete To Do?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="67"/>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="187"/>
        <source>To-do</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="188"/>
        <source>Incident</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="189"/>
        <source>Task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="190"/>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockMyTodo.js" line="157"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <location filename="../scripts/dockPayables.js" line="25"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPayables.js" line="26"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPayables.js" line="72"/>
        <source>0+ Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPayables.js" line="73"/>
        <source>0-30 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPayables.js" line="74"/>
        <source>31-60 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPayables.js" line="75"/>
        <source>61-90 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPayables.js" line="76"/>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPayables.js" line="77"/>
        <source>Total Open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="24"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="25"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="26"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="72"/>
        <source>Planned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="73"/>
        <source>Firmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="75"/>
        <source>Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="76"/>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="77"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="78"/>
        <source>At Receiving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="79"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchActive.js" line="80"/>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="39"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="45"/>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="101"/>
        <source>Non-Inventory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="130"/>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="132"/>
        <source>Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="135"/>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="137"/>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="139"/>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="141"/>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="223"/>
        <source>Unsupported Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="224"/>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="310"/>
        <source>Vendor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="311"/>
        <location filename="../scripts/dockPurchHist.js" line="321"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="315"/>
        <source>Item Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="316"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="320"/>
        <source>Purch. Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="324"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchHist.js" line="325"/>
        <source>Qty.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="24"/>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="25"/>
        <source>Vendor#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="26"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="27"/>
        <source>Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="28"/>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="29"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="30"/>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="31"/>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="32"/>
        <source>Ship Via</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="33"/>
        <source>Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="34"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="76"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockPurchOpen.js" line="77"/>
        <source>Unreleased</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <location filename="../scripts/dockReceivables.js" line="25"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockReceivables.js" line="26"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockReceivables.js" line="72"/>
        <source>0+ Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockReceivables.js" line="73"/>
        <source>0-30 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockReceivables.js" line="74"/>
        <source>31-60 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockReceivables.js" line="75"/>
        <source>61-90 Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockReceivables.js" line="76"/>
        <source>90+ days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockReceivables.js" line="77"/>
        <source>Total Open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="24"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="25"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="26"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="60"/>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="61"/>
        <source>Orders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="62"/>
        <source>To Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="63"/>
        <source>Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="64"/>
        <source>At Shipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="65"/>
        <source>Shipped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="66"/>
        <source>To Bill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesActive.js" line="67"/>
        <source>Invoiced</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="39"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="45"/>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="131"/>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="133"/>
        <source>Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="136"/>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="138"/>
        <source>this Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="140"/>
        <source>this Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="142"/>
        <source>this Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="144"/>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="269"/>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="270"/>
        <location filename="../scripts/dockSalesHistory.js" line="280"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="274"/>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="275"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="279"/>
        <source>Sales Rep.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="283"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesHistory.js" line="284"/>
        <source>Qty.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="24"/>
        <source>Order#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="25"/>
        <source>Customer#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="26"/>
        <source>Bill To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="27"/>
        <source>Bill Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="28"/>
        <source>Bill Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="29"/>
        <source>Ship To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="30"/>
        <source>Ship Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="31"/>
        <source>Ship Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="32"/>
        <source>Ship Via</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="33"/>
        <source>Sched. Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSalesOpen.js" line="34"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <location filename="../scripts/dockSendMessage.js" line="32"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSendMessage.js" line="38"/>
        <source>Preferences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSendMessage.js" line="119"/>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSendMessage.js" line="120"/>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSendMessage.js" line="192"/>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSendMessage.js" line="324"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockSendMessage.js" line="328"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <location filename="../scripts/dockUserOnline.js" line="24"/>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockUserOnline.js" line="25"/>
        <source>Proper Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockUserOnline.js" line="26"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockUserOnline.js" line="27"/>
        <source># Internal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockUserOnline.js" line="28"/>
        <source># External</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockUserOnline.js" line="29"/>
        <source>Client Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockUserOnline.js" line="30"/>
        <source>Query Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dockUserOnline.js" line="31"/>
        <source>Client Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <location filename="../scripts/initMenu.js" line="37"/>
        <source>Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="46"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="51"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="109"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="122"/>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="167"/>
        <source>Sites</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <location filename="../scripts/preferencesComment.js" line="43"/>
        <location filename="../scripts/preferencesComment.js" line="54"/>
        <location filename="../scripts/preferencesComment.js" line="67"/>
        <location filename="../scripts/preferencesComment.js" line="174"/>
        <location filename="../scripts/preferencesComment.js" line="186"/>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesComment.js" line="194"/>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesComment.js" line="195"/>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/preferencesComment.ui" line="14"/>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="18"/>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="19"/>
        <source>This Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="20"/>
        <source>This Month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="21"/>
        <source>This Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="22"/>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="36"/>
        <source>Bookings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="37"/>
        <source>Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="39"/>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="40"/>
        <source>Product Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="41"/>
        <source>Sales Rep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="43"/>
        <source>Sales History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="47"/>
        <location filename="../scripts/preferencesHistory.js" line="58"/>
        <source>Receipts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="48"/>
        <source>Variances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="50"/>
        <source>Vendor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="51"/>
        <location filename="../scripts/preferencesHistory.js" line="62"/>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="52"/>
        <source>Purchase Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="54"/>
        <source>Purchase History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="61"/>
        <source>Class Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="63"/>
        <source>Planner Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesHistory.js" line="65"/>
        <source>Manufacture History Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/preferencesHistory.ui" line="27"/>
        <source>History Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/preferencesHistory.ui" line="33"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/preferencesHistory.ui" line="63"/>
        <source>Group By:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/preferencesHistory.ui" line="83"/>
        <source>Time Frame:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <location filename="../uiforms/preferencesNumber.ui" line="14"/>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/preferencesNumber.ui" line="24"/>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <location filename="../scripts/preferencesSelections.js" line="13"/>
        <source>Account#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesSelections.js" line="14"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesSelections.js" line="15"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesSelections.js" line="18"/>
        <source>Asset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesSelections.js" line="19"/>
        <source>Liability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesSelections.js" line="20"/>
        <source>Revenue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesSelections.js" line="21"/>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/preferencesSelections.js" line="22"/>
        <source>Equity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/preferencesSelections.ui" line="21"/>
        <source>Selection Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/preferencesSelections.ui" line="44"/>
        <source>Select Accounts to monitor:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <location filename="../scripts/sendMessageToUser.js" line="27"/>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/sendMessageToUser.js" line="28"/>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/sendMessageToUser.ui" line="14"/>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/sendMessageToUser.ui" line="20"/>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/sendMessageToUser.ui" line="42"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/sendMessageToUser.ui" line="52"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/sendMessageToUser.ui" line="81"/>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <location filename="../scripts/systemMessage.js" line="8"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <location filename="../scripts/userPreferences.js" line="34"/>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/userPreferences.js" line="37"/>
        <source>Manual Refresh Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/userPreferences.js" line="76"/>
        <location filename="../scripts/userPreferences.js" line="88"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

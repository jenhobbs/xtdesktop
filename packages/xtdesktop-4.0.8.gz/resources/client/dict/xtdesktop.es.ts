<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>desktop</name>
    <message>
        <source>Desktop</source>
        <translation type="unfinished">Escritorio</translation>
    </message>
</context>
<context>
    <name>desktopAccounting</name>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">Proveedor</translation>
    </message>
    <message>
        <source>Workbench</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation>dspBillingSelections</translation>
    </message>
    <message>
        <source>Accounting</source>
        <translation>Contabilidad</translation>
    </message>
    <message>
        <source>Payables</source>
        <translation>Acreedores</translation>
    </message>
    <message>
        <source>Receivables</source>
        <translation>Deudores</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>General Ledger</source>
        <translation>Libro Mayor</translation>
    </message>
    <message>
        <source>Chart of Accounts</source>
        <translation>Plan de Cuentas</translation>
    </message>
    <message>
        <source>Budget</source>
        <translation>Presupuesto</translation>
    </message>
    <message>
        <source>Standard Journal</source>
        <translation>Diario Estándar</translation>
    </message>
    <message>
        <source>Journal Series</source>
        <translation>Grupo de Diario</translation>
    </message>
    <message>
        <source>Bank Accounts</source>
        <translation>Cuentas Bancarias</translation>
    </message>
    <message>
        <source>Adjustment</source>
        <translation>Ajuste</translation>
    </message>
    <message>
        <source>Reconcile</source>
        <translation>Conciliar</translation>
    </message>
    <message>
        <source>Reporting</source>
        <translation>Generación de informes</translation>
    </message>
    <message>
        <source>Financial Statements</source>
        <translation>Estados Financieros</translation>
    </message>
    <message>
        <source>Trial Balance</source>
        <translation>Balance de Sumas y Saldos</translation>
    </message>
    <message>
        <source>Transactions</source>
        <translation>Transacciones</translation>
    </message>
    <message>
        <source>Monitored Accounts</source>
        <translation>Cuentas de Control</translation>
    </message>
    <message>
        <source>b</source>
        <translation>¿b?</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Antigüedad</translation>
    </message>
</context>
<context>
    <name>desktopCRM</name>
    <message>
        <source>Corporate Relationship Management</source>
        <translation type="unfinished">Gestión de Relaciones Corporativas</translation>
    </message>
    <message>
        <source>Project Orders</source>
        <translation>Órdenes de Proyecto</translation>
    </message>
    <message>
        <source>Time &amp; Expense</source>
        <translation>Tiempo y Gasto</translation>
    </message>
    <message>
        <source>Account Management</source>
        <translation>Gestión de Cuentas</translation>
    </message>
    <message>
        <source>My Accounts</source>
        <translation>Mis Cuentas</translation>
    </message>
    <message>
        <source>Incidents</source>
        <translation>Incidencias</translation>
    </message>
    <message>
        <source>Pre-Sales</source>
        <translation>Pre-Ventas</translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation>Cuentas</translation>
    </message>
    <message>
        <source>Event Manager</source>
        <translation>Gestor de Eventos</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>Clientes potenciales</translation>
    </message>
    <message>
        <source>Customer Workbench</source>
        <translation>Herramientas de Clientes</translation>
    </message>
    <message>
        <source>To Do</source>
        <translation>Pendiente</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation>dspBillingSelections</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>Proyecto</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Presupuestos</translation>
    </message>
    <message>
        <source>Quotes by Item</source>
        <translation>Presupuestos por Producto</translation>
    </message>
    <message>
        <source>Opportunities</source>
        <translation>Oportunidades</translation>
    </message>
    <message>
        <source>Contacts</source>
        <translation>Contactos</translation>
    </message>
    <message>
        <source>Address Book</source>
        <translation>Listín</translation>
    </message>
    <message>
        <source>Projects</source>
        <translation>Proyectos</translation>
    </message>
    <message>
        <source>Corporate</source>
        <translation>Corporativo</translation>
    </message>
    <message>
        <source>To Do Calendar</source>
        <translation>Calendario de Pendientes</translation>
    </message>
    <message>
        <source>My Contacts</source>
        <translation>Mis Contactos</translation>
    </message>
    <message>
        <source>To Do List</source>
        <translation>Lista de Pendientes</translation>
    </message>
    <message>
        <source>CRM</source>
        <translation>CRM</translation>
    </message>
    <message>
        <source>Personal</source>
        <translation>Personal</translation>
    </message>
</context>
<context>
    <name>desktopMaintenance</name>
    <message>
        <source>Assignments</source>
        <translation>Asignaciones</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Seguridad</translation>
    </message>
    <message>
        <source>coin_clock_48</source>
        <translation>coin_clock_48</translation>
    </message>
    <message>
        <source>Extensions</source>
        <translation>Extensiones</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>Informes</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>Scripts</translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation>Lista de Materiales</translation>
    </message>
    <message>
        <source>MetaSQL</source>
        <translation>MetaSQL</translation>
    </message>
    <message>
        <source>Exchange Rates</source>
        <translation>Tipos de Cambio</translation>
    </message>
    <message>
        <source>Design</source>
        <translation>Diseño</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>Pantallas</translation>
    </message>
    <message>
        <source>Commands</source>
        <translation>Comandos</translation>
    </message>
    <message>
        <source>Currencies</source>
        <translation>Monedas</translation>
    </message>
    <message>
        <source>Currency</source>
        <translation>Moneda</translation>
    </message>
    <message>
        <source>Roles</source>
        <translation>Roles</translation>
    </message>
    <message>
        <source>Users</source>
        <translation>Usuarios</translation>
    </message>
    <message>
        <source>Inventory</source>
        <translation>Inventario</translation>
    </message>
    <message>
        <source>Schedules</source>
        <translation>Programaciones</translation>
    </message>
    <message>
        <source>Locations</source>
        <translation>Ubicaciones</translation>
    </message>
    <message>
        <source>Site</source>
        <translation>Centro</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation>dspBillingSelections</translation>
    </message>
    <message>
        <source>Items</source>
        <translation>Productos</translation>
    </message>
    <message>
        <source>Pricing</source>
        <translation>Preciario</translation>
    </message>
    <message>
        <source>Maintenance</source>
        <translation>Mantenimiento</translation>
    </message>
    <message>
        <source>Products</source>
        <translation>Productos</translation>
    </message>
</context>
<context>
    <name>desktopManufacture</name>
    <message>
        <source>Work Orders</source>
        <translation type="unfinished">Órdenes de Trabajo</translation>
    </message>
    <message>
        <source>Order Schedule</source>
        <translation>Programación de Órdenes</translation>
    </message>
    <message>
        <source>Manufacture History</source>
        <translation>Historial de Fabricación</translation>
    </message>
    <message>
        <source>Material Availability</source>
        <translation>Disponibilidad de Material</translation>
    </message>
    <message>
        <source>Post Scrap</source>
        <translation>Registrar Rechazo</translation>
    </message>
    <message>
        <source>Manufacture Activities</source>
        <translation>Actividades de Fabricación</translation>
    </message>
    <message>
        <source>Release</source>
        <translation>Liberar</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Disponibilidad de Inventario</translation>
    </message>
    <message>
        <source>Process</source>
        <translation>Procesar</translation>
    </message>
    <message>
        <source>Material Requirements</source>
        <translation>Requisitos de Material</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Close Work Order</source>
        <translation>Cerrar Orden de Trabajo</translation>
    </message>
    <message>
        <source>Issue Material</source>
        <translation>Dar Salida a Material</translation>
    </message>
    <message>
        <source>Post Production</source>
        <translation>Registrar Producción</translation>
    </message>
    <message>
        <source>Costing</source>
        <translation>Costes</translation>
    </message>
    <message>
        <source>Return Material</source>
        <translation>Devolver Material</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historial</translation>
    </message>
    <message>
        <source>Correct Production</source>
        <translation>Corregir Producción</translation>
    </message>
    <message>
        <source>Plan</source>
        <translation>Planificación</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etiqueta</translation>
    </message>
    <message>
        <source>Manufacture</source>
        <translation>Fabricación</translation>
    </message>
    <message>
        <source>Create Work Order</source>
        <translation>Crear Orden de Trabajo</translation>
    </message>
    <message>
        <source>b</source>
        <translation>¿b?</translation>
    </message>
</context>
<context>
    <name>desktopMenuBar</name>
    <message>
        <source>MAIN MENU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SHORTCUTS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> &gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Shortcuts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insufficient Privileges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have insufficient permissions for this action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the shortcut action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Employee&lt;/p&gt;&lt;p&gt;Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>desktopNotice</name>
    <message>
        <source>Note: The xTuple Desktop is only available when user preferences are set to show windows as free-floating.</source>
        <translation type="unfinished">Nota: El Escritorio xTuple está disponible sólo cuando en las preferencias de usuario se activan las ventanas flotantes.</translation>
    </message>
    <message>
        <source>Notice</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <source>Remind me about this again.</source>
        <translation>Recordarme más tarde.</translation>
    </message>
</context>
<context>
    <name>desktopPurchase</name>
    <message>
        <source>Release</source>
        <translation type="unfinished">Liberar</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Pedido</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etiqueta</translation>
    </message>
    <message>
        <source>Purchase History</source>
        <translation>Historial de Compras</translation>
    </message>
    <message>
        <source>Purchase Activities</source>
        <translation>Actividades de Compra</translation>
    </message>
    <message>
        <source>Open Items</source>
        <translation>Artículos Abiertos</translation>
    </message>
    <message>
        <source>Uninvoiced Receipts</source>
        <translation>Recibos no facturados</translation>
    </message>
    <message>
        <source>Enter Receipts</source>
        <translation>Introducir Recibos</translation>
    </message>
    <message>
        <source>Select for Payment</source>
        <translation>Seleccionar para Pago</translation>
    </message>
    <message>
        <source>b</source>
        <translation>¿b?</translation>
    </message>
    <message>
        <source>Purchase</source>
        <translation>Compra</translation>
    </message>
    <message>
        <source>Purchase Orders</source>
        <translation>Órdenes de Compra</translation>
    </message>
    <message>
        <source>ViewAPOpenItems</source>
        <translation>ViewAPOpenItems</translation>
    </message>
    <message>
        <source>Purchase Requests</source>
        <translation>Peticiones de Compra</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Create Purchase Order</source>
        <translation>Crear Orden de Compra</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Disponibilidad de Inventario</translation>
    </message>
    <message>
        <source>Receive</source>
        <translation>Recibir</translation>
    </message>
    <message>
        <source>Unposted Receipts</source>
        <translation>Recibos no contabilizados</translation>
    </message>
    <message>
        <source>Payment</source>
        <translation>Pago</translation>
    </message>
    <message>
        <source>Vouchers</source>
        <translation>Justificantes</translation>
    </message>
    <message>
        <source>Check Register</source>
        <translation>Registro de Cheques</translation>
    </message>
    <message>
        <source>Selected Payments</source>
        <translation>Pagos Seleccionados</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Antigüedad</translation>
    </message>
    <message>
        <source>dspTimePhasedOpenAPItems</source>
        <translation>dspTimePhasedOpenAPItems</translation>
    </message>
    <message>
        <source>Check Run</source>
        <translation>Proceso de Verificación</translation>
    </message>
</context>
<context>
    <name>desktopSales</name>
    <message>
        <source>Cash Receipts</source>
        <translation type="unfinished">Recibos de Caja</translation>
    </message>
    <message>
        <source>Ship</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <source>New Customer</source>
        <translation>Nuevo Cliente</translation>
    </message>
    <message>
        <source>Inventory Availability</source>
        <translation>Disponibilidad de Inventario</translation>
    </message>
    <message>
        <source>Issue To Shipping</source>
        <translation>Proceder a Enviar</translation>
    </message>
    <message>
        <source>Sales Activities</source>
        <translation>Actividades de Ventas</translation>
    </message>
    <message>
        <source>Prospects</source>
        <translation>Clientes potenciales</translation>
    </message>
    <message>
        <source>Order</source>
        <translation>Pedido</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Ventas</translation>
    </message>
    <message>
        <source>Sales Orders</source>
        <translation>Órdenes de Venta</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etiqueta</translation>
    </message>
    <message>
        <source>Sales History</source>
        <translation>Historial de Ventas</translation>
    </message>
    <message>
        <source>b</source>
        <translation>¿b?</translation>
    </message>
    <message>
        <source>Backlog</source>
        <translation>Retraso</translation>
    </message>
    <message>
        <source>Select for Billing</source>
        <translation>Seleccionar para Facturar</translation>
    </message>
    <message>
        <source>dspBillingSelections</source>
        <translation>dspBillingSelections</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Presupuestos</translation>
    </message>
    <message>
        <source>New Sales Order</source>
        <translation>Nueva Orden de Venta</translation>
    </message>
    <message>
        <source>Print Packing Lists</source>
        <translation>Imprimir Lista de Embalaje</translation>
    </message>
    <message>
        <source>Maintain Shipping</source>
        <translation>Mantener el Envío</translation>
    </message>
    <message>
        <source>Bill</source>
        <translation>Factura</translation>
    </message>
    <message>
        <source>Create Invoices</source>
        <translation>Crear Facturas</translation>
    </message>
    <message>
        <source>Aging</source>
        <translation>Antigüedad</translation>
    </message>
    <message>
        <source>Post Invoices</source>
        <translation>Contabilizar Facturas</translation>
    </message>
</context>
<context>
    <name>desktopSocial</name>
    <message>
        <source>Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>b</source>
        <translation type="unfinished">¿b?</translation>
    </message>
    <message>
        <source>Send Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Users Online</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockBankBal</name>
    <message>
        <source>Balance</source>
        <translation type="unfinished">Saldo</translation>
    </message>
    <message>
        <source>Reconcile...</source>
        <translation>Conciliar...</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
</context>
<context>
    <name>dockExtensions</name>
    <message>
        <source>MetaSQL</source>
        <translation type="unfinished">MetaSQL</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <source>Triggers</source>
        <translation>Disparos</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Stored Procedures</source>
        <translation>Procedimientos Almacenados</translation>
    </message>
    <message>
        <source>Scripts</source>
        <translation>Scripts</translation>
    </message>
    <message>
        <source>Reports</source>
        <translation>Informes</translation>
    </message>
    <message>
        <source>Screens</source>
        <translation>Pantallas</translation>
    </message>
    <message>
        <source>Schema</source>
        <translation>Esquema</translation>
    </message>
    <message>
        <source>Tables</source>
        <translation>Tablas</translation>
    </message>
    <message>
        <source>Client</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>Carpeta</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Privileges</source>
        <translation>Permisos</translation>
    </message>
    <message>
        <source>Database</source>
        <translation>Base de datos</translation>
    </message>
    <message>
        <source>Views</source>
        <translation>Vistas</translation>
    </message>
    <message>
        <source>Custom Commands</source>
        <translation>Comandos Personalizados</translation>
    </message>
</context>
<context>
    <name>dockGLAccounts</name>
    <message>
        <source>Liability</source>
        <translation type="unfinished">Pasivo</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation>Ingreso</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Número</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferencias...</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation>Patrimonio</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation>Gasto</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation>Activo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
</context>
<context>
    <name>dockMessageHistory</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished">Recargar</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">Preferencias...</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation type="unfinished">Abrir...</translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockMfgActive</name>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>Expandido</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation>Planificado</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Monto</translation>
    </message>
    <message>
        <source>#</source>
        <translation>Nº</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation>Cant.</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>Liberado</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>En Proceso</translation>
    </message>
</context>
<context>
    <name>dockMfgHist</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>Número de Artículo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>Código de Clase</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>este Año</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation>Código de Planificador</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>esta Semana</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>Recibos</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>este Mes</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoy</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferencias...</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>Cant.</translation>
    </message>
</context>
<context>
    <name>dockMfgOpen</name>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Fecha Inicial</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Released</source>
        <translation>Liberado</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Whs.</source>
        <translation>Almacenes</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Item#</source>
        <translation>Nº Producto</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>Nº Pedido</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Recibido</translation>
    </message>
    <message>
        <source>WIP Value</source>
        <translation>Valor de Trabajo en Curso</translation>
    </message>
    <message>
        <source>Ordered</source>
        <translation>Pedido</translation>
    </message>
    <message>
        <source>UOM</source>
        <translation>UM</translation>
    </message>
    <message>
        <source>Posted Value</source>
        <translation>Valor Apuntado</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Fecha de Vencimiento</translation>
    </message>
    <message>
        <source>Condition</source>
        <translation>Condición</translation>
    </message>
    <message>
        <source>In Process</source>
        <translation>En Proceso</translation>
    </message>
    <message>
        <source>Exploded</source>
        <translation>Expandido</translation>
    </message>
</context>
<context>
    <name>dockMyAccounts</name>
    <message>
        <source>Postal Code</source>
        <translation type="unfinished">Código Postal</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Número</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>Contacto</translation>
    </message>
    <message>
        <source>City</source>
        <translation>Ciudad</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Correo electrónico</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Teléfono</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
</context>
<context>
    <name>dockMyContacts</name>
    <message>
        <source>City</source>
        <translation type="unfinished">Ciudad</translation>
    </message>
    <message>
        <source>Postal Code</source>
        <translation>Código Postal</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>Nombre de la Cuenta</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Nº de Cuenta</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Teléfono</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Correo electrónico</translation>
    </message>
</context>
<context>
    <name>dockMyTodo</name>
    <message>
        <source>Parent#</source>
        <translation type="unfinished">Nº de Antecesor</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation>Fecha Inicial</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Assigned To</source>
        <translation>Asignado a</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Fecha de Vencimiento</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <source>This will permenantly delete the To Do item.  Are you sure?</source>
        <translation>Esto eliminará permanentemente la Tarea Pendiente. ¿Está seguro?</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Nº de Cuenta</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation>Nº de Cliente</translation>
    </message>
    <message>
        <source>Delete To Do?</source>
        <translation>¿Eliminar Pendiente?</translation>
    </message>
    <message>
        <source>Owner</source>
        <translation>Propietario</translation>
    </message>
    <message>
        <source>Account Name</source>
        <translation>Nombre de la Cuenta</translation>
    </message>
    <message>
        <source>Project</source>
        <translation>Proyecto</translation>
    </message>
    <message>
        <source>Task</source>
        <translation>Tarea</translation>
    </message>
    <message>
        <source>Incident</source>
        <translation>Incidencia</translation>
    </message>
    <message>
        <source>To-do</source>
        <translation>Pendiente</translation>
    </message>
</context>
<context>
    <name>dockPayables</name>
    <message>
        <source>0+ Days</source>
        <translation type="unfinished">0+ Días</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>+90 Días</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30 Días</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>Total Pendiente</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60 Días</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90 Días</translation>
    </message>
</context>
<context>
    <name>dockPurchActive</name>
    <message>
        <source>Firmed</source>
        <translation type="unfinished">En Firme</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Requests</source>
        <translation>Peticiones</translation>
    </message>
    <message>
        <source>Planned</source>
        <translation>Planificado</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation>Con justificante</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Monto</translation>
    </message>
    <message>
        <source>At Receiving</source>
        <translation>Al Recibir</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>No lanzado</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Recibido</translation>
    </message>
    <message>
        <source>#</source>
        <translation>Nº</translation>
    </message>
</context>
<context>
    <name>dockPurchHist</name>
    <message>
        <source>Non-Inventory</source>
        <translation type="unfinished">No perteneciente al Inventario</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Monto</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferencias...</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <source>Vendor</source>
        <translation>Proveedor</translation>
    </message>
    <message>
        <source>Unsupported Action</source>
        <translation>Acción no soportada</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>Recibos</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation>Desviaciones</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>este Año</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoy</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>este Mes</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>esta Semana</translation>
    </message>
    <message>
        <source>Drill down on Non-Inventory Items is not yet supported</source>
        <translation>Aún no está implementada la Investigación en Productos que no pertenecen al Inventario</translation>
    </message>
    <message>
        <source>Purch. Agent</source>
        <translation>Agente de Compras</translation>
    </message>
    <message>
        <source>Item Number</source>
        <translation>Número de Artículo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>Cant.</translation>
    </message>
</context>
<context>
    <name>dockPurchOpen</name>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <source>Unreleased</source>
        <translation>No lanzado</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Monto</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Teléfono</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation>Teléfono Receptor</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>Enviar por</translation>
    </message>
    <message>
        <source>Due Date</source>
        <translation>Fecha de Vencimiento</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation>Contacto de Envío</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>Nº de Pedido</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Vendor#</source>
        <translation>Nº de Proveedor</translation>
    </message>
    <message>
        <source>Contact</source>
        <translation>Contacto</translation>
    </message>
</context>
<context>
    <name>dockReceivables</name>
    <message>
        <source>Status</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <source>31-60 Days</source>
        <translation>31-60 Días</translation>
    </message>
    <message>
        <source>Total Open</source>
        <translation>Total Abierto</translation>
    </message>
    <message>
        <source>0-30 Days</source>
        <translation>0-30 Días</translation>
    </message>
    <message>
        <source>0+ Days</source>
        <translation>0+ Días</translation>
    </message>
    <message>
        <source>90+ days</source>
        <translation>+90 Días</translation>
    </message>
    <message>
        <source>61-90 Days</source>
        <translation>61-90 Días</translation>
    </message>
    <message>
        <source>Balance</source>
        <translation>Saldo</translation>
    </message>
</context>
<context>
    <name>dockSalesActive</name>
    <message>
        <source>Orders</source>
        <translation type="unfinished">Pedidos</translation>
    </message>
    <message>
        <source>Quotes</source>
        <translation>Presupuestos</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Monto</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>#</source>
        <translation>Nº</translation>
    </message>
    <message>
        <source>At Shipping</source>
        <translation>Al Embarque</translation>
    </message>
    <message>
        <source>To Print</source>
        <translation>A Imprimir</translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation>Facturado</translation>
    </message>
    <message>
        <source>Shipped</source>
        <translation>Embarcado</translation>
    </message>
    <message>
        <source>To Bill</source>
        <translation>A Cobrar</translation>
    </message>
    <message>
        <source>Pick</source>
        <translation>Recoger</translation>
    </message>
</context>
<context>
    <name>dockSalesHistory</name>
    <message>
        <source>Product Category</source>
        <translation type="unfinished">Categoría de Producto</translation>
    </message>
    <message>
        <source>Qty.</source>
        <translation>Cant.</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Monto</translation>
    </message>
    <message>
        <source>Sales Rep.</source>
        <translation>Rep. Ventas</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoy</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Ventas</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation>Reservas</translation>
    </message>
    <message>
        <source>this Month</source>
        <translation>este Mes</translation>
    </message>
    <message>
        <source>this Week</source>
        <translation>esta Semana</translation>
    </message>
    <message>
        <source>this Year</source>
        <translation>este Año</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Recargar</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferencias...</translation>
    </message>
    <message>
        <source>this Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockSalesOpen</name>
    <message>
        <source>Amount</source>
        <translation type="unfinished">Monto</translation>
    </message>
    <message>
        <source>Ship Via</source>
        <translation>Enviar Por</translation>
    </message>
    <message>
        <source>Sched. Date</source>
        <translation>Fecha Prog.</translation>
    </message>
    <message>
        <source>Customer#</source>
        <translation>Nº de Cliente</translation>
    </message>
    <message>
        <source>Order#</source>
        <translation>Nº de Pedido</translation>
    </message>
    <message>
        <source>Bill Contact</source>
        <translation>Contacto de Facturación</translation>
    </message>
    <message>
        <source>Bill To</source>
        <translation>Facturar A</translation>
    </message>
    <message>
        <source>Ship To</source>
        <translation>Enviar A</translation>
    </message>
    <message>
        <source>Ship Phone</source>
        <translation>Teléfono Receptor</translation>
    </message>
    <message>
        <source>Bill Phone</source>
        <translation>Teléfono de Facturación</translation>
    </message>
    <message>
        <source>Ship Contact</source>
        <translation>Contacto de Envío</translation>
    </message>
</context>
<context>
    <name>dockSendMessage</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished">Recargar</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation type="unfinished">Preferencias...</translation>
    </message>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Message to Yourself. Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dockUserOnline</name>
    <message>
        <source># Internal</source>
        <translation type="unfinished">Nº Interno</translation>
    </message>
    <message>
        <source>Query Start</source>
        <translation>Inicio de Consulta</translation>
    </message>
    <message>
        <source># External</source>
        <translation>Nº Externo</translation>
    </message>
    <message>
        <source>Proper Name</source>
        <translation>Nombre Propio</translation>
    </message>
    <message>
        <source>Client Address</source>
        <translation>Dirección del Cliente</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <source>Client Start</source>
        <translation>Arranque del Cliente</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Correo electrónico</translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Setup</source>
        <translation type="unfinished">Configuración</translation>
    </message>
    <message>
        <source>Open...</source>
        <translation>Abrir...</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation>Bienvenido</translation>
    </message>
    <message>
        <source>Sites</source>
        <translation>Sedes</translation>
    </message>
    <message>
        <source>Dashboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesComment</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Date Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Start Date changed to honor 7 day limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment Preference</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesHistory</name>
    <message>
        <source>Vendor</source>
        <translation type="unfinished">Proveedor</translation>
    </message>
    <message>
        <source>Variances</source>
        <translation>Desviaciones</translation>
    </message>
    <message>
        <source>Receipts</source>
        <translation>Recibos</translation>
    </message>
    <message>
        <source>Product Category</source>
        <translation>Categoría de Producto</translation>
    </message>
    <message>
        <source>Sales Rep</source>
        <translation>Rep. Ventas</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation>Código de Clase</translation>
    </message>
    <message>
        <source>Purchase History Preferences</source>
        <translation>Preferencias del Historial de Compras</translation>
    </message>
    <message>
        <source>Purchase Agent</source>
        <translation>Agente de Compras</translation>
    </message>
    <message>
        <source>Manufacture History Preferences</source>
        <translation>Preferencias del Historial de Fabricación</translation>
    </message>
    <message>
        <source>Group By:</source>
        <translation>Agrupar Por:</translation>
    </message>
    <message>
        <source>Time Frame:</source>
        <translation>Marco Temporal:</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Producto</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <source>Bookings</source>
        <translation>Reservas</translation>
    </message>
    <message>
        <source>History Settings</source>
        <translation>Ajustes de Historial</translation>
    </message>
    <message>
        <source>This Year</source>
        <translation>Este Año</translation>
    </message>
    <message>
        <source>This Week</source>
        <translation>Esta Semana</translation>
    </message>
    <message>
        <source>This Month</source>
        <translation>Este Mes</translation>
    </message>
    <message>
        <source>Planner Code</source>
        <translation>Código de Planificador</translation>
    </message>
    <message>
        <source>Sales History Preferences</source>
        <translation>Preferencias del Historial de Ventas</translation>
    </message>
    <message>
        <source>Sales</source>
        <translation>Ventas</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation>Cliente</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoy</translation>
    </message>
    <message>
        <source>This Fiscal Year</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesNumber</name>
    <message>
        <source>Number Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Messages to display:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>preferencesSelections</name>
    <message>
        <source>Liability</source>
        <translation type="unfinished">Pasivo</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>Account#</source>
        <translation>Nº de Cuenta</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Asset</source>
        <translation>Activo</translation>
    </message>
    <message>
        <source>Select Accounts to monitor:</source>
        <translation>Seleccionar Cuentas a monitorizar:</translation>
    </message>
    <message>
        <source>Selection Preferences</source>
        <translation>Preferencias de Selección</translation>
    </message>
    <message>
        <source>Revenue</source>
        <translation>Ingreso</translation>
    </message>
    <message>
        <source>Equity</source>
        <translation type="unfinished">Patrimonio</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation>Gasto</translation>
    </message>
</context>
<context>
    <name>sendMessageToUser</name>
    <message>
        <source>Send Message?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You are trying to Send Reply Message to Yourself.
Are you sure that you really want to Continue?.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Message to User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>systemMessage</name>
    <message>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>userPreferences</name>
    <message>
        <source>Use Native Application Styling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual Refresh Comment Console</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
